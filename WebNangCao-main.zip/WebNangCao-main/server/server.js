const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const session = require("express-session");
const path = require("path");
const multer = require("multer");
const bcrypt = require("bcryptjs");

const productRoutes = require("../routes/productRoutes");
const categoryRoutes = require("../routes/categoryRoutes");
const cartRoutes = require("../routes/cartRoutes");
const registerRoutes = require("../routes/registerRoutes");
const authMiddleware = require('../middleware/authMiddleware');

const Product = require("../models/Product");
const Category = require("../models/Category");
const User = require("../models/User");

const app = express();
const PORT = process.env.PORT || 3000;
const sendResetPasswordEmail = require("./mailService");

// Cấu hình session
app.use(session({
    secret: '12345',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Nếu dùng HTTPS thì chuyển thành true
}));

// Middleware hỗ trợ gửi dữ liệu
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Kết nối MongoDB
const MONGO_URI = "mongodb+srv://annguyen1212004:0963631472An@project.e63li.mongodb.net/?retryWrites=true&w=majority";
const connectDatabase = async () => {
    try {
        await mongoose.connect(MONGO_URI, {
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
            autoIndex: true,
        });
        console.log("✅ Kết nối MongoDB thành công");
        await seedCategories(); // Tạo danh mục mặc định nếu chưa có
    } catch (error) {
        console.error("❌ Lỗi kết nối MongoDB:", error);
        process.exit(1);
    }
};
connectDatabase();

// Cấu hình view engine và thư mục tĩnh
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "../views"));
app.use(express.static(path.join(__dirname, "../public")));
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

// Các route công khai
app.use("/register", registerRoutes);

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', async (req, res) => {
    let { username, password } = req.body;
    username = username.trim().toLowerCase();
    const user = await User.findOne({ username });
    if (!user) {
        return res.send("Tài khoản không tồn tại. <a href='/login'>Thử lại</a>");
    }
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
        return res.send("Sai mật khẩu. <a href='/login'>Thử lại</a>");
    }
    req.session.user = { username: user.username };
    res.redirect('/');
});

app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

// Route quên mật khẩu
app.get("/forgot-password", (req, res) => {
    res.render("forgot-password");
});
app.post("/forgot-password", async (req, res) => {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
        return res.send("Email không tồn tại trong hệ thống. <a href='/forgot-password'>Thử lại</a>");
    }
    try {
        await sendResetPasswordEmail(email, user._id);
        res.send("Đã gửi hướng dẫn đặt lại mật khẩu đến email của bạn.");
    } catch (error) {
        console.error("Lỗi gửi email:", error);
        res.send("Không thể gửi email. Vui lòng thử lại.");
    }
});

// Áp dụng authMiddleware cho các route cần đăng nhập
app.use(authMiddleware);

// Route trang chủ
app.get("/", async (req, res) => {
    try {
        const products = await Product.find().sort({ _id: -1 }).limit(6);
        res.render("index", { title: "Trang chủ", products });
    } catch (error) {
        console.error("❌ Lỗi tải sản phẩm:", error);
        res.render("index", { title: "Trang chủ", products: [] });
    }
});

// Các route liên quan đến sản phẩm được mount tại "/products"
// (bao gồm cả route thêm sản phẩm /products/create, được định nghĩa trong productRoutes)
app.use("/products", productRoutes);

app.get('/reset-password/:token', async (req, res) => {
    const { token } = req.params;
    const user = await User.findOne({ resetToken: token, tokenExpiry: { $gt: Date.now() } });
    if (!user) {
        return res.send("Token không hợp lệ hoặc đã hết hạn. <a href='/forgot-password'>Thử lại</a>");
    }
    res.render('reset-password', { token });
});
app.post('/reset-password', async (req, res) => {
    const { token, password, confirmPassword } = req.body;
    if (password !== confirmPassword) {
        return res.send("Mật khẩu không khớp. <a href='/reset-password'>Thử lại</a>");
    }
    const user = await User.findOne({ resetToken: token, tokenExpiry: { $gt: Date.now() } });
    if (!user) {
        return res.send("Token không hợp lệ hoặc đã hết hạn. <a href='/forgot-password'>Thử lại</a>");
    }
    user.password = await bcrypt.hash(password, 10);
    user.resetToken = undefined;
    user.tokenExpiry = undefined;
    await user.save();
    res.send("Mật khẩu đã được đặt lại thành công. <a href='/login'>Đăng nhập</a>");
});

// Các route API khác
app.use("/api/categories", categoryRoutes);
app.use(cartRoutes);
// Sửa destination để lưu file vào thư mục "../uploads"
const upload = multer({
    dest: path.join(__dirname, "../uploads"),
    limits: { fileSize: 10 * 1024 * 1024 }, // Giới hạn 10MB
    fileFilter: (req, file, cb) => {
        const fileTypes = /jpeg|jpg|png|gif/;
        const extname = fileTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = fileTypes.test(file.mimetype);
        if (extname && mimetype) {
            return cb(null, true);
        } else {
            cb(new Error("Lỗi: Chỉ chấp nhận các file ảnh (jpg, jpeg, png, gif)"));
        }
    }
});

// Khởi động server
app.listen(PORT, () => {
    console.log(`🚀 Server chạy tại http://localhost:${PORT}`);
});

// Hàm tạo danh mục mặc định
const seedCategories = async () => {
    const defaultCategories = ["Điện thoại", "Laptop", "Phụ kiện", "Thời trang"];
    for (const categoryName of defaultCategories) {
        const exists = await Category.findOne({ name: categoryName });
        if (!exists) {
            await Category.create({ name: categoryName });
            console.log(`✅ Đã thêm danh mục: ${categoryName}`);
        }
    }
};
