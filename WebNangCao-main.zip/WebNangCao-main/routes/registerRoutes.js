const express = require('express');
const router = express.Router();

// Import mô hình người dùng (User)
const User = require('../models/User');

// Route hiển thị trang đăng ký
router.get('/', (req, res) => {
    res.render('register'); // Render view đăng ký
});

// Route xử lý đăng ký tài khoản
router.post('/', async (req, res) => {
    let { username, email, password } = req.body;

    // Chuẩn hóa dữ liệu: loại bỏ khoảng trắng dư và chuyển về chữ thường
    username = username.trim().toLowerCase();
    email = email.trim().toLowerCase();

    // Kiểm tra nếu email đã tồn tại
    const existingUser = await User.findOne({ email });
    if (existingUser) {
        return res.send("Email đã tồn tại. <a href='/register'>Thử lại</a>");
    }

    // Tạo người dùng mới - mật khẩu sẽ được mã hóa tự động trong pre-save hook của mô hình User
    const newUser = new User({
        username,
        email,
        password,
    });

    try {
        await newUser.save(); // Lưu người dùng vào MongoDB
        res.send("Đăng ký thành công! <a href='/login'>Đăng nhập ngay</a>");
    } catch (error) {
        console.error("Lỗi khi đăng ký:", error);
        res.send("Đã có lỗi xảy ra. Vui lòng thử lại.");
    }
});

module.exports = router;
